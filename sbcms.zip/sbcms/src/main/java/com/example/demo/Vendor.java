package com.example.demo;

public class Vendor {
	private int VenId;
	private String VenName;
	private String VenPHNno;
	private String VenUserName;
	private String VenPassword;
	private String VenEmail;
	public int getVenId() {
		return VenId;
	}
	public void setVenId(int venId) {
		VenId = venId;
	}
	public String getVenName() {
		return VenName;
	}
	public void setVenName(String venName) {
		VenName = venName;
	}
	public String getVenPHNno() {
		return VenPHNno;
	}
	public void setVenPHNno(String venPHNno) {
		VenPHNno = venPHNno;
	}
	public String getVenUserName() {
		return VenUserName;
	}
	public void setVenUserName(String venUserName) {
		VenUserName = venUserName;
	}
	public String getVenPassword() {
		return VenPassword;
	}
	public void setVenPassword(String venPassword) {
		VenPassword = venPassword;
	}
	public String getVenEmail() {
		return VenEmail;
	}
	public void setVenEmail(String venEmail) {
		VenEmail = venEmail;
	}
	@Override
	public String toString() {
		return "Vendor [VenId=" + VenId + ", VenName=" + VenName + ", VenPHNno=" + VenPHNno + ", VenUserName="
				+ VenUserName + ", VenPassword=" + VenPassword + ", VenEmail=" + VenEmail + "]";
	}

}
