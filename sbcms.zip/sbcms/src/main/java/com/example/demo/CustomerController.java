package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class CustomerController {

	@Autowired 
	CanteenDAO dao;
	
	@GetMapping(value="/cus")
	public List<Customer> showCustomer() {
		return dao.showCustomer();
	}
	@GetMapping(value="/cussearch/{cusid}")
	public Customer searchByCustomerId(@PathVariable int cusid) {
		return dao.searchByCustomerId(cusid);
	}
	@GetMapping(value="/cusorders/{cusid}")
	public List<Orders> customerOrders(@PathVariable int cusid) {
	return dao.customerOrders(cusid);
	}
	@GetMapping(value="/cuspendingrorders/{cusid}/{pending}")
	public List<Orders> customerOrderpending(@PathVariable int cusid,@PathVariable String pending) {
	return dao.customerOrderpending(cusid,pending);
	}
	
	}
