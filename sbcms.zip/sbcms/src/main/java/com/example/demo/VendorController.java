package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
@RestController
public class VendorController {

	@Autowired 
	CanteenDAO dao;
	
	@GetMapping(value="/vendor")
	public List<Vendor> showVendor() {
		return dao.showVendor();
}
	@GetMapping(value="/vendororders/{venid}")
	public List<Orders> VendorOrders(@PathVariable int venid) {
		return dao.VendorOrders(venid);
}
	
}
