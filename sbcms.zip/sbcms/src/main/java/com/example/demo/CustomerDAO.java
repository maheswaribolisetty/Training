package com.example.demo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
@Repository
public class CustomerDAO {
	@Autowired
	private JdbcTemplate jdbcTemplate;

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	
	public Customer searchByCustomerId(int cusId) {
		String cmd ="select * from Customer where CUS_ID=?";
		List<Customer> customerList = jdbcTemplate.query(cmd, new Object[] {cusId}, new RowMapper<Customer>() {

			@Override
			public Customer mapRow(ResultSet rs, int rowNum) throws SQLException {
				Customer customer = new Customer();
				customer.setCusId(rs.getInt("CUS_ID"));
				customer.setCusName(rs.getString("CUS_NAME"));
//				customer.setCusPHNno(rs.getString("CUS_PHONE NO"));
				customer.setCusUserName(rs.getString("CUS_USERNAME"));
				customer.setCusPassword(rs.getString("CUS_PASSWORD"));
				customer.setCusEmail(rs.getString("CUS_EMAIL"));
				return customer;
			}
		});
		if (customerList.size()==1) {
			return customerList.get(0);
		}
		return null;
	}
	
	public List<Customer> showCustomer() {
		String cmd ="select * from Customer";
		List<Customer> customerList = jdbcTemplate.query(cmd, new RowMapper<Customer>() {

			@Override
			public Customer mapRow(ResultSet rs, int rowNum) throws SQLException {
				Customer customer = new Customer();
		        customer.setCusId(rs.getInt("CUS_ID"));
				customer.setCusName(rs.getString("CUS_NAME"));
		//		customer.setCusPHNno(rs.getString("CUS_PHN NO"));
			customer.setCusUserName(rs.getString("CUS_USERNAME"));
			customer.setCusPassword(rs.getString("CUS_PASSWORD"));
		customer.setCusEmail(rs.getString("CUS_EMAIL"));
				return customer;
			}
		});
		return customerList;
	}
	public String customerAuthentication(String user1, String pwd1) {
		String cmd = "select count(*) cnt from Customer where CUS_UserName=? AND "
				+ " CUS_Password=?";
		List str=jdbcTemplate.query(cmd,new Object[] {user1,pwd1}, new RowMapper() {

			@Override
			public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
				// TODO Auto-generated method stub
				return rs.getInt("cnt");
			}
			
		});
		return  str.get(0).toString();
	}
}



