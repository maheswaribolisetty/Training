package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
@RestController
public class OrderController {

	@Autowired 
	CanteenDAO dao;
	
	@GetMapping(value="/orders")
	public List<Orders> showOrder() {
		return dao.showOrder();
	}
	@GetMapping(value="/ordsearch/{ordid}")
	public Orders searchByOrderId(@PathVariable int ordid) {
		return dao.searchByOrderId(ordid);
	}
}
