package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
@RestController
public class MenuController {
	@Autowired 
	CanteenDAO dao;
	
	@GetMapping(value="/menu")
	public List<Menu> showMenu() {
		return dao.showMenu();
}
	@GetMapping(value="/menusearch/{menuid}")
	public Menu searchByMenuId(@PathVariable int menuid) {
		return dao.searchByMenuId(menuid);
}
}	